// Sample X Export - like.js format

window.YTD.like.part0 = [
  {
    "like": {
      "tweetId": "9876543210987654321",
      "fullText": "Great insights on AI development!",
      "created_at": "2024-01-10T08:00:00Z"
    }
  },
  {
    "like": {
      "tweetId": "9876543210987654322",
      "fullText": "Python tips that actually work.",
      "created_at": "2024-01-12T15:30:00Z"
    }
  }
]
