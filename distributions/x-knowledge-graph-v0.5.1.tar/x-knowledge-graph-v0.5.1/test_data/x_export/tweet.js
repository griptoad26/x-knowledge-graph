window.YTD.tweet.part0 = [
  {
    "tweet": {
      "id": "1234567890123456789",
      "text": "Working on a new project. Need to finish the API integration by Friday.",
      "created_at": "2024-01-15T10:30:00Z",
      "user": {"id": "9876543210", "screen_name": "testuser"},
      "in_reply_to_status_id": null,
      "conversation_id": "1234567890123456789",
      "entities": {"hashtags": [{"text": "coding"}], "urls": [], "mentions": []},
      "metrics": {"retweet_count": 0, "reply_count": 2, "like_count": 5, "quote_count": 0}
    }
  },
  {
    "tweet": {
      "id": "1234567890123456790",
      "text": "TODO: Review the documentation and update the examples. This is urgent for the team.",
      "created_at": "2024-01-15T14:22:00Z",
      "user": {"id": "9876543210", "screen_name": "testuser"},
      "in_reply_to_status_id": null,
      "conversation_id": "1234567890123456790",
      "entities": {"hashtags": [], "urls": [], "mentions": []},
      "metrics": {"retweet_count": 1, "reply_count": 3, "like_count": 8, "quote_count": 0}
    }
  },
  {
    "tweet": {
      "id": "1234567890123456791",
      "text": "Remember to schedule a meeting with the design team about the new UI components.",
      "created_at": "2024-01-16T09:15:00Z",
      "user": {"id": "9876543210", "screen_name": "testuser"},
      "in_reply_to_status_id": null,
      "conversation_id": "1234567890123456791",
      "entities": {"hashtags": [{"text": "design"}], "urls": [], "mentions": []},
      "metrics": {"retweet_count": 0, "reply_count": 1, "like_count": 3, "quote_count": 0}
    }
  },
  {
    "tweet": {
      "id": "1234567890123456792",
      "text": "Going to refactor the authentication module next week. Should improve performance significantly.",
      "created_at": "2024-01-16T11:00:00Z",
      "user": {"id": "9876543210", "screen_name": "testuser"},
      "in_reply_to_status_id": null,
      "conversation_id": "1234567890123456792",
      "entities": {"hashtags": [], "urls": [], "mentions": []},
      "metrics": {"retweet_count": 0, "reply_count": 0, "like_count": 2, "quote_count": 0}
    }
  },
  {
    "tweet": {
      "id": "1234567890123456793",
      "text": "Don't forget to backup the database before the maintenance window tonight.",
      "created_at": "2024-01-16T18:45:00Z",
      "user": {"id": "9876543210", "screen_name": "testuser"},
      "in_reply_to_status_id": null,
      "conversation_id": "1234567890123456793",
      "entities": {"hashtags": [], "urls": [], "mentions": []},
      "metrics": {"retweet_count": 0, "reply_count": 1, "like_count": 4, "quote_count": 0}
    }
  }
]
